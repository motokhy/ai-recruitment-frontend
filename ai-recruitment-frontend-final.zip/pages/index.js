import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Home() {
  const [jobs, setJobs] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', job_id: '', resume_link: '' });
  const [result, setResult] = useState('');

  useEffect(() => {
    axios.get("https://5e49f778-36df-439a-bf56-06e8dd749a29-00-2uo3vggl192gl.sisko.replit.dev/jobs")
      .then(res => setJobs(res.data));
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post("https://5e49f778-36df-439a-bf56-06e8dd749a29-00-2uo3vggl192gl.sisko.replit.dev/apply", form);
    setResult(res.data.ai_evaluation);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>AI Recruitment System</h1>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Name" onChange={handleChange} required /><br />
        <input name="email" placeholder="Email" onChange={handleChange} required /><br />
        <select name="job_id" onChange={handleChange} required>
          <option value="">Select a Job</option>
          {jobs.map(job => (
            <option key={job.id} value={job.id}>
              {job.title} ({job.location})
            </option>
          ))}
        </select><br />
        <input name="resume_link" placeholder="Resume Link" onChange={handleChange} required /><br />
        <button type="submit">Apply</button>
      </form>
      {result && <p><strong>AI Evaluation:</strong> {result}</p>}
    </div>
  );
}