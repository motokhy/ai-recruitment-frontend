import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Jobs() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    axios.get(process.env.NEXT_PUBLIC_BACKEND_URL + '/jobs').then(res => setJobs(res.data));
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Job Listings</h2>
      <ul className="space-y-2">
        {jobs.map(job => (
          <li key={job.id} className="border p-4 rounded">
            <h3 className="font-semibold">{job.title}</h3>
            <p>{job.location} - {job.seniority}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}