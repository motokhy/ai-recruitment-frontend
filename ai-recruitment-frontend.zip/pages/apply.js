import { useState, useEffect } from 'react';
import axios from 'axios';

export default function Apply() {
  const [jobs, setJobs] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', resume_link: '', job_id: '' });
  const [result, setResult] = useState('');

  useEffect(() => {
    axios.get(process.env.NEXT_PUBLIC_BACKEND_URL + '/jobs').then(res => setJobs(res.data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/apply', form);
    setResult(res.data.ai_evaluation);
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl mb-4 font-bold">Apply for a Job</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input className="border p-2 w-full" placeholder="Name" onChange={(e) => setForm({...form, name: e.target.value})} />
        <input className="border p-2 w-full" placeholder="Email" onChange={(e) => setForm({...form, email: e.target.value})} />
        <input className="border p-2 w-full" placeholder="Resume Link" onChange={(e) => setForm({...form, resume_link: e.target.value})} />
        <select className="border p-2 w-full" onChange={(e) => setForm({...form, job_id: e.target.value})}>
          <option value="">Select Job</option>
          {jobs.map((job) => (
            <option key={job.id} value={job.id}>{job.title}</option>
          ))}
        </select>
        <button className="bg-blue-600 text-white px-4 py-2" type="submit">Submit</button>
      </form>
      {result && (
        <div className="mt-4 bg-gray-100 p-4 rounded">
          <strong>AI Evaluation:</strong>
          <p>{result}</p>
        </div>
      )}
    </div>
  );
}